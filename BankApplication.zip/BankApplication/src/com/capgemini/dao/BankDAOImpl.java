package com.capgemini.dao;

import java.util.HashMap;

import com.capgemini.banking.bean.Customer;

public class BankDAOImpl implements BankDAO{

	HashMap<Long, Customer> hashMap = new HashMap<Long, Customer>();
}
