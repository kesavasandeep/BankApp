package com.capgemini.dao;

public interface BankDAO {

}
