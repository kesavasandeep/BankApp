package com.capgemini.banking.service;

import java.util.HashMap;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.bean.Transaction;
import com.capgemini.banking.exception.AccountNotFoundException;
import com.capgemini.banking.exception.InSufficientBalanceException;

public class BankServiceImpl implements BankService {
	Account[] accounts;
	Transaction[] transactions = new Transaction[100];
	HashMap<Integer , Account> map_Account = new HashMap<Integer , Account>();

	public BankServiceImpl(int size) {
		super();
		accounts = new Account[size];
	}

	public void creatAccount(Account account) {
		for (int i = 0; i < accounts.length; i++) {
			if (accounts[i] == null) {
				accounts[i] = account;
				System.out.println("Account Number: "+account.getAccNum());
				break;
			}
		}
	}

	public void deposit(int accNum, int amount) throws AccountNotFoundException{
		int i;
		for (i = 0; i < accounts.length; i++) {
			if (accounts[i] != null && accounts[i].getAccNum() == accNum) {
				accounts[i].setAccBal(accounts[i].getAccBal() + amount);
				System.out.println("Amount Deposited into " + accounts[i].getAccNum()
						+ " account holder Id\nDeposited Amount is : rs" + amount + "\nAccount Availble Balance is : rs"
						+ accounts[i].getAccBal());
				break;
			}
		}
		if (i == accounts.length)
			throw new AccountNotFoundException("deposit->Unable to find an account  ...");

	}

	public void withdraw(int accNum, int amount) throws AccountNotFoundException, InSufficientBalanceException{
		int i;
		for (i = 0; i < accounts.length; i++) {
			if (accounts[i] != null && accounts[i].getAccNum() == accNum) {
				if(accounts[i].getAccBal()>=amount){
					accounts[i].setAccBal(accounts[i].getAccBal() - amount);
					System.out.println("Amount Withdrawn from " + accounts[i].getAccNum()
							+ " account holder Id\nWithdrawn Amount is : rs" + amount + "\nAccount Availble Balance is : rs"
							+ accounts[i].getAccBal());
					break;
				}
				else
					throw new InSufficientBalanceException("withdraw->In Sufficient BalanceException ...");
			}
		}
		if (i == accounts.length)
			throw new AccountNotFoundException("withdraw->Unable to find an account  ...");
	}

	public void fundTransfer(int accNum1, int accNum2, int amount)  throws AccountNotFoundException, InSufficientBalanceException{
		int i, j;
		for (i = 0; i < accounts.length; i++) {
			if (accounts[i] != null && accounts[i].getAccNum() == accNum1) {
				break;
			}
		}
		if (i == accounts.length)
			throw new AccountNotFoundException("Fund Transfer->Unable to find an account 1 ...");
		for (j = 0; j < accounts.length; j++) {
			if (accounts[j] != null && accounts[j].getAccNum() == accNum2) {
				break;
			}
		}
		if (j == accounts.length)
			throw new AccountNotFoundException("Fund Transfer->Unable to find an account 2 ...");
		else if(accounts[i].getAccBal()>=amount) {
			accounts[i].setAccBal(accounts[i].getAccBal() - amount);
			accounts[j].setAccBal(accounts[j].getAccBal() + amount);
		}
		else 
			throw new InSufficientBalanceException("Fund Transfer->In Sufficient BalanceException ...");
	}

	public void showBalance(int accNum) throws AccountNotFoundException {
		int i;
		for (i = 0; i < accounts.length; i++) {
			if (accounts[i]!=null && accounts[i].getAccNum() == accNum) {
				
				System.out.println("Availble Balance : "+accounts[i].getAccBal());
				break;
			}
		}
		if (i == accounts.length)
			throw new AccountNotFoundException("showBalance->Unable to find an account...");
	}
	
	@Override
	public void listAll() {
		for(int i=0;i<accounts.length;i++){
			if(accounts[i] != null )
				System.out.println(accounts[i]);
		}
	}

	public void createTransaction(Transaction transaction) {
		for (int i = 0; i < transactions.length; i++) {
			if (transactions[i] == null) {
				transactions[i] = transaction;
				break;
			}
		}
	}

	public void printTransaction(int accNum) throws AccountNotFoundException {
		int i = 0;
		if (transactions[i] == null)
			System.out.println("Transactions not Done yet");
		else {
			for (i = 0; i < transactions.length; i++) {
				if (transactions[i] != null && transactions[i].getAccNum() == accNum) {
					System.out.println(transactions[i]);
				}
			}
			if (i == accounts.length)
				throw new AccountNotFoundException("showBalance->Unable to find an account...");
		}
	}
}