package com.capgemini.banking.service;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.bean.Transaction;
import com.capgemini.banking.exception.AccountNotFoundException;
import com.capgemini.banking.exception.InSufficientBalanceException;

public interface BankService {

	public void creatAccount(Account account);

	public void showBalance(int accNum) throws AccountNotFoundException;

	public void deposit(int accNum, int amount) throws AccountNotFoundException;

	public void withdraw(int accNum, int amount) throws AccountNotFoundException, InSufficientBalanceException;

	public void fundTransfer(int accNum1, int accNum2, int amount) throws AccountNotFoundException, InSufficientBalanceException;

	public void listAll();

	public void printTransaction(int accNum) throws AccountNotFoundException;

	public void createTransaction(Transaction transaction);
}