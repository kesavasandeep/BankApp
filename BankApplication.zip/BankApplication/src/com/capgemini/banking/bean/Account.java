package com.capgemini.banking.bean;

public class Account {
	
	private int accNum;
	private int accBal;
	private Customer customer;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getAccNum() {
		return accNum;
	}

	public void setAccNum(int accNum) {
		this.accNum = accNum;
	}

	public int getAccBal() {
		return accBal;
	}

	public void setAccBal(int accBal) {
		this.accBal = accBal;
	}

	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", accBal=" + accBal + ", customer=" + customer + "]";
	}
}
