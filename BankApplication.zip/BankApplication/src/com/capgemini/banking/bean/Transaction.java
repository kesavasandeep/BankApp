package com.capgemini.banking.bean;

public class Transaction {

	private int transId;
	private int accNum;
	private String transType;
	private int amount;

	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Transaction(int transId, int accNum, String transType, int amount) {
		super();
		this.transId = transId;
		this.accNum = accNum;
		this.transType = transType;
		this.amount = amount;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getAccNum() {
		return accNum;
	}

	public void setAccNum(int accNum) {
		this.accNum = accNum;
	}

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	@Override
	public String toString() {
		return "Transaction [transId=" + transId + ", accNum=" + accNum + ", transType=" + transType + ", amount="
				+ amount + "]";
	}
}
