package com.capgemini.banking;

import java.util.Scanner;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.bean.Address;
import com.capgemini.banking.bean.Customer;
import com.capgemini.banking.bean.Transaction;
import com.capgemini.banking.exception.AccountNotFoundException;
import com.capgemini.banking.exception.InSufficientBalanceException;
import com.capgemini.banking.service.BankService;
import com.capgemini.banking.service.BankServiceImpl;

public class Main {
	static Scanner sc = new Scanner(System.in);
	static int count = 101;
	static int transId = 201;

	public static int getInputNum(String message) {
		int acnum;
		System.out.println(message);
		acnum = sc.nextInt();
		return acnum;
	}

	public static String getInputText(String message) {
		String acnum;
		System.out.println(message);
		acnum = sc.next();
		return acnum;
	}

	public static Transaction generateTransaction(int transId, int accNum, String transType, int amount) {
		Transaction transaction = new Transaction();

		transaction.setTransId(transId);
		transaction.setAccNum(accNum);
		transaction.setAmount(amount);
		transaction.setTransType(transType);

		return transaction;
	}

	public static Account getAccount() {
		Account account = new Account();
		Customer customer = new Customer();
		Address address = new Address();

		customer.setFirstName(getInputText("Enter the customer First name:"));
		customer.setLastName(getInputText("Enter the customer Last name:"));
		customer.setGmail(getInputText("Enter the customer Email :"));
		customer.setPhoneNo(getInputText("Enter the customer PhoneNo:"));
		customer.setCustId(count);

		address.setdNo(getInputText("Enter the customer Door no:"));
		address.setStreet(getInputText("Enter the customer Street name:"));
		address.setCity(getInputText("Enter the customer City name:"));
		address.setState(getInputText("Enter the customer State name:"));
		address.setPincode(getInputText("Enter the customer Pincode:"));

		account.setAccBal(getInputNum("Enter the initial installment:"));
		account.setAccNum(count++);

		customer.setAddress(address);
		account.setCustomer(customer);
		return account;
	}

	public static void main(String[] args) {
		BankService accountOperation = new BankServiceImpl(50);

		int choice = 0;

		do {
			System.out.println("\n\n<<===== Welcome to Capgemini Bank =====>");
			System.out.println("1.Create Bank Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.listAll");
			System.out.println("7.Print Transaction");
			System.out.println("8.Exit");
			System.out.println("Enter Choice:");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				accountOperation.creatAccount(getAccount());
				System.out.println("Account Created****->");
				break;

			case 2:
				try {
					accountOperation.showBalance(getInputNum("Show Balance:->Enter Account number: "));
				} catch (AccountNotFoundException e) {
					System.err.println(e.getMessage());
				}
				break;

			case 3:
				int ACCNUMd = getInputNum("Enter Account number :"), AMOUNTd = getInputNum("Enter amount");
				try {
					accountOperation.deposit(ACCNUMd, AMOUNTd);
				} catch (AccountNotFoundException e) {
					System.err.println(e.getMessage());
				}
				accountOperation.createTransaction(generateTransaction(transId++, ACCNUMd, "credited", AMOUNTd));
				break;

			case 4:
				int ACCNUMw = getInputNum("Enter Account number :"), AMOUNTw = getInputNum("Enter amount");
				try {
					accountOperation.withdraw(ACCNUMw, AMOUNTw);
				} catch (AccountNotFoundException | InSufficientBalanceException e) {
					System.err.println(e.getMessage());
				}
				accountOperation.createTransaction(generateTransaction(transId++, ACCNUMw, "debited", AMOUNTw));
				break;

			case 5:
				int ACCNUM1 = getInputNum("Enter Main Account number :");
				int ACCNUM2 = getInputNum("Enter Benificiary Account number :");
				int AMOUNT = getInputNum("Enter amount");

				try {
					accountOperation.fundTransfer(ACCNUM1, ACCNUM2, AMOUNT);
				} catch (AccountNotFoundException | InSufficientBalanceException e) {
					System.err.println(e.getMessage());
				}
				accountOperation.createTransaction(generateTransaction(transId++, ACCNUM1, "debited->fund transfer", AMOUNT));
				accountOperation.createTransaction(generateTransaction(transId++, ACCNUM2, "credited->fund transfer", AMOUNT));
				System.out.println("Fund transfer done****->\n");
				break;

			case 6:
				accountOperation.listAll();
				break;

			case 7:
				try {
					accountOperation.printTransaction(getInputNum("Enter Account number to get the all Transactions:"));
				} catch (AccountNotFoundException e) {
					System.err.println(e.getMessage());
				}
				break;
				
			case 8:
				break;
				
			default:
				System.out.println("Invalid Choice");
				break;

			}
		} while (choice != 8);
	}
}